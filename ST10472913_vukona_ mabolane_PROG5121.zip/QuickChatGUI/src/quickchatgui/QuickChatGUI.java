/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package quickchatgui;

/**
 *
 * @author RC_Student_lab
 */
public class QuickChatGUI {
    
import javax.swing.JOptionPane;
import java.awt.AWTEvent;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;



    private static Map<String, User> users = new HashMap<>();
    private static java.util.List<String> messages = new java.util.ArrayList<>();
    private static User loggedInUser;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> showRegistrationScreen());
    }

    private static void showRegistrationScreen() {
        JFrame frame = new JFrame("QuickChat - Registration");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new GridLayout(6, 2));

        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JTextField cellphoneField = new JTextField();
        JTextField firstNameField = new JTextField();

        frame.add(new JLabel("Username:"));
        frame.add(usernameField);

        frame.add(new JLabel("Password:"));
        frame.add(passwordField);

        frame.add(new JLabel("Cellphone Number:"));
        frame.add(cellphoneField);

        frame.add(new JLabel("First Name:"));
        frame.add(firstNameField);

        JButton registerButton = new JButton("Register");
        frame.add(registerButton);

        JButton goToLoginButton = new JButton("Already Registered? Login");
        frame.add(goToLoginButton);

        registerButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String cellphone = cellphoneField.getText();
            String firstName = firstNameField.getText();

            if (username.isEmpty() || password.isEmpty() || cellphone.isEmpty() || firstName.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            users.put(username, new User(username, password, cellphone, firstName));
            JOptionPane.showMessageDialog(frame, "Registration successful! Please login.");
            frame.dispose();
            showLoginScreen();
        });

        goToLoginButton.addActionListener(e -> {
            frame.dispose();
            showLoginScreen();
        });

        frame.setVisible(true);
    }

    private static void showLoginScreen() {
        JFrame frame = new JFrame("QuickChat - Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);
        frame.setLayout(new GridLayout(3, 2));

        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();

        frame.add(new JLabel("Username:"));
        frame.add(usernameField);

        frame.add(new JLabel("Password:"));
        frame.add(passwordField);

        JButton loginButton = new JButton("Login");
        frame.add(loginButton);

        loginButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            User user = users.get(username);
            if (user != null && user.password.equals(password)) {
                loggedInUser = user;
                JOptionPane.showMessageDialog(frame, "Welcome " + user.username + " (" + user.firstName + "), it is great to see you again.");
                frame.dispose();
                showMainMenu();
            } else {
                JOptionPane.showMessageDialog(frame, "Invalid credentials. Try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        frame.setVisible(true);
    }

    private static void showMainMenu() {
        JFrame frame = new JFrame("QuickChat - Menu");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 300);
        frame.setLayout(new GridLayout(4, 1));

        JLabel welcomeLabel = new JLabel("Welcome to QuickChat!", SwingConstants.CENTER);
        frame.add(welcomeLabel);

        JButton sendButton = new JButton("A. Send a Message");
        JButton viewButton = new JButton("B. Show Recently Sent Messages");
        JButton quitButton = new JButton("C. Quit");

        frame.add(sendButton);
        frame.add(viewButton);
        frame.add(quitButton);

        sendButton.addActionListener(e -> {
            String msg = JOptionPane.showInputDialog(frame, "Enter your message:");
            if (msg != null && !msg.trim().isEmpty()) {
                messages.add(loggedInUser.username + ": " + msg);
                JOptionPane.showMessageDialog(frame, "Message sent!");
            }
        });

        viewButton.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            for (String msg : messages) {
                sb.append(msg).append("\n");
            }
            JTextArea textArea = new JTextArea(sb.toString());
            textArea.setEditable(false);
            JOptionPane.showMessageDialog(frame, new JScrollPane(textArea), "Recent Messages", JOptionPane.INFORMATION_MESSAGE);
        });

        quitButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(frame, "You have logged out. Goodbye!");
            frame.dispose();
            System.exit(0);
        });

        frame.setVisible(true);
    }

    static class User {
        String username;
        String password;
        String cellphone;
        String firstName;

        User(String username, String password, String cellphone, String firstName) {
            this.username = username;
            this.password = password;
            this.cellphone = cellphone;
            this.firstName = firstName;
        }
    }
}

 